
UI.Help = {
    showHelp: function () {
        var helpDiv = document.getElementById("helpScreen");
        helpDiv.style.visibility = "visible";
        UI.windowStack.push("help");
    },
    hideHelp: function () {
        if(peek(UI.windowStack) === "help") {
            UI.windowStack.pop();
            var helpDiv = document.getElementById("helpScreen");
            helpDiv.style.visibility = "hidden";
        }
    }
}
