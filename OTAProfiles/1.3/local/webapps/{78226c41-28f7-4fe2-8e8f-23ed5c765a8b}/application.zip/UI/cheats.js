UI.Cheats = {
    fixAllWindows: function() {
        var windows  = ig.game.level.squashWindows();
        for(var i = 0; i < windows.length; ++i) {
            windows[i].repairWindow();
        }
    }
};
