#!/bin/bash
files=$(ls backup/ | grep ogg | cut -d . -f 1)
echo $cur
for cur in $files
do
	sox backup/$cur.ogg -r 8k -C -1 $cur.ogg
	sox backup/$cur.ogg -r 4k -b 8 -e unsigned-integer $cur.wav
done
