Test = {};

Test.initEvents = function () {
    document.write("start");
    //var audio = document.getElementsByName("audio")[0];
    //audio.play();
    var hidden;
    var visibilityChanged;
    if (typeof document.hidden !== "undefined") {
        hidden = "hidden";
        visibilityChanged = "visibilitychange";
    } else if (typeof document.mozHidden !== "undefined") {
        hidden = "mozHidden";
        visibilityChanged = "mozvisibilitychange";
    } else if (typeof document.msHidden !== "undefined") {
        hidden = "msHidden";
        visibilityChanged = "msvisibilitychange";
    } else if (typeof document.webkitHidden !== "undefined") {
        hidden = "webkitHidden";
        visibilityChanged = "webkitvisibilitychange";
    }
    document.writeln(visibilityChanged);
    document.addEventListener("mozvisibilitychange", function () {
        //we want to pass in a bool from the correct page property
        document.write("fired");
    });
    document.addEventListener("blur", function () {
        console.log("blur");
    })
}