puzzle
======

Puzzle Game based on HTML/CSS/JS Technologies

screenshots
======

![ScreenShot](https://raw.github.com/crdlc/FOS-Slides/master/template/images/puzzle%201.png)
![ScreenShot](https://raw.github.com/crdlc/FOS-Slides/master/template/images/lists.png)
![ScreenShot](https://raw.github.com/crdlc/FOS-Slides/master/template/images/game%201.png)
![ScreenShot](https://raw.github.com/crdlc/FOS-Slides/master/template/images/game%202.png)